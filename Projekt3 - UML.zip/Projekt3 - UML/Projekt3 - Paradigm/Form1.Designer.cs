﻿namespace Projekt3___Paradigm
{
    partial class FormParadigm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            pictureBox = new PictureBox();
            Createclass = new ContextMenuStrip(components);
            toolStripMenuItemCreateClass = new ToolStripMenuItem();
            arrowToolStripMenuItem = new ToolStripMenuItem();
            fromToolStripMenuItem = new ToolStripMenuItem();
            toToolStripMenuItem = new ToolStripMenuItem();
            cancelToolStripMenuItem = new ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)pictureBox).BeginInit();
            Createclass.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox
            // 
            pictureBox.Location = new Point(12, 12);
            pictureBox.Name = "pictureBox";
            pictureBox.Size = new Size(1461, 579);
            pictureBox.TabIndex = 0;
            pictureBox.TabStop = false;
            pictureBox.Paint += pictureBox_Paint;
            pictureBox.MouseDoubleClick += pictureBox_MouseDoubleClick;
            pictureBox.MouseDown += pictureBox_MouseDown;
            pictureBox.MouseMove += pictureBox_MouseMove;
            pictureBox.MouseUp += pictureBox_MouseUp;
            // 
            // Createclass
            // 
            Createclass.Items.AddRange(new ToolStripItem[] { toolStripMenuItemCreateClass, arrowToolStripMenuItem });
            Createclass.Name = "contextMenuStrip1";
            Createclass.Size = new Size(137, 48);
            Createclass.MouseUp += pictureBox_MouseUp;
            // 
            // toolStripMenuItemCreateClass
            // 
            toolStripMenuItemCreateClass.Name = "toolStripMenuItemCreateClass";
            toolStripMenuItemCreateClass.Size = new Size(136, 22);
            toolStripMenuItemCreateClass.Text = "Create class";
            toolStripMenuItemCreateClass.Click += toolStripMenuItemCreateClass_Click;
            // 
            // arrowToolStripMenuItem
            // 
            arrowToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { fromToolStripMenuItem, toToolStripMenuItem, cancelToolStripMenuItem });
            arrowToolStripMenuItem.Name = "arrowToolStripMenuItem";
            arrowToolStripMenuItem.Size = new Size(136, 22);
            arrowToolStripMenuItem.Text = "Arrow";
            // 
            // fromToolStripMenuItem
            // 
            fromToolStripMenuItem.Name = "fromToolStripMenuItem";
            fromToolStripMenuItem.Size = new Size(110, 22);
            fromToolStripMenuItem.Text = "From";
            fromToolStripMenuItem.Click += fromToolStripMenuItem_Click;
            // 
            // toToolStripMenuItem
            // 
            toToolStripMenuItem.Name = "toToolStripMenuItem";
            toToolStripMenuItem.Size = new Size(110, 22);
            toToolStripMenuItem.Text = "To";
            toToolStripMenuItem.Click += toToolStripMenuItem_Click;
            // 
            // cancelToolStripMenuItem
            // 
            cancelToolStripMenuItem.Name = "cancelToolStripMenuItem";
            cancelToolStripMenuItem.Size = new Size(110, 22);
            cancelToolStripMenuItem.Text = "Cancel";
            cancelToolStripMenuItem.Click += cancelToolStripMenuItem_Click;
            // 
            // FormParadigm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1485, 603);
            Controls.Add(pictureBox);
            Name = "FormParadigm";
            Text = "Paradigm";
            FormClosing += FormParadigm_FormClosing;
            ((System.ComponentModel.ISupportInitialize)pictureBox).EndInit();
            Createclass.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox;
        private ContextMenuStrip Createclass;
        private ToolStripMenuItem arrowToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItemCreateClass;
        private ToolStripMenuItem fromToolStripMenuItem;
        private ToolStripMenuItem toToolStripMenuItem;
        private ToolStripMenuItem cancelToolStripMenuItem;
    }
}