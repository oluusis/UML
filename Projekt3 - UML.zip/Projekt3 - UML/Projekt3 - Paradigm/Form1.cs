using Projekt3___Paradigm.Changers;
using Projekt3___Paradigm.Service_classes;
using System.Windows.Forms;

namespace Projekt3___Paradigm
{
    public partial class FormParadigm : Form
    {
        public Control control { get; set; }
        public Service ClassService { get; set; }

        public FormParadigm()
        {
            InitializeComponent();
            this.control = new Control();
            this.ClassService = Service.Instance;

            this.pictureBox.MouseWheel += MouseWheel;
            this.KeyDown += KeyDownS;
        }

        public new void KeyDownS(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.S)
            {
                Bitmap bitmap = new Bitmap(this.pictureBox.Width, this.pictureBox.Height);
                this.pictureBox.DrawToBitmap(bitmap, new Rectangle(0, 0, this.pictureBox.Width, this.pictureBox.Height));

                string filePath = Path.Combine(Environment.CurrentDirectory, "screenshot.png");
                bitmap.Save(filePath, System.Drawing.Imaging.ImageFormat.Png);
            }
        }

        public new void MouseWheel(object sender, MouseEventArgs e)
        {
            this.control.Zoom(e.Delta, e.Location, this.pictureBox);
        }

        private void pictureBox_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.Createclass.Show(Cursor.Position);
                this.location = e.Location;
            }

            if (e.Button == MouseButtons.Middle)
            {
                this.control.PlaneMover.changing = false;
            }
            this.control.MouseUp(e.Location);
        }




        private void pictureBox_Paint(object sender, PaintEventArgs e)
        {
            control.Draw(e.Graphics);
        }

        private void pictureBox_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (this.control.ClickClass(e.Location))
            {
                EditClass editClass = new EditClass(control.AttachedClass);

                if (editClass.ShowDialog() != DialogResult.OK) return;

                if (editClass == null) return;

                control.AttachedClass = editClass.Class;
                this.ClassService.Context.SaveChanges();

                this.control.UpdateSize(e.Location);

            }
        }


        private void pictureBox_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Middle)
            {
                this.control.PlaneMover = PlaneChanger.GetInstance(e.Location);
                this.control.PlaneMover.changing = true;
                return;
            }
            this.control.MouseDown(e.Location);
        }

        private void pictureBox_MouseMove(object sender, MouseEventArgs e)
        {
            this.control.MouseMove(e.Location);

            this.pictureBox.Refresh();

        }

        private Point location { get; set; }

        private void toolStripMenuItemCreateClass_Click(object sender, EventArgs e)
        {
            control.CreateClass(this.location);
        }

        private void fromToolStripMenuItem_Click(object sender, EventArgs e)
        {
            control.CreateArrow(this.location);
        }

        private void toToolStripMenuItem_Click(object sender, EventArgs e)
        {
            control.EndArrow(this.location);
        }

        private void cancelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            control.CancelArrow();
        }

        private void FormParadigm_FormClosing(object sender, FormClosingEventArgs e)
        {
            control.CancelArrow();
            this.ClassService.Context.SaveChanges();
        }

    }
}