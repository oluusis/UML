﻿using Projekt3___Paradigm.BO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt3___Paradigm.EditForms
{
    public partial class MethodAttributeEdit : Form
    {
        public MethodAttribute MethodAttribute { get; set; }

        public MethodAttributeEdit(MethodAttribute methodAttribute)
        {
            this.MethodAttribute = methodAttribute;
            InitializeComponent();

            this.textBoxName.Text = MethodAttribute.Name;
            this.textBoxDataType.Text = MethodAttribute.DataType;
        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
            {
                this.MethodAttribute.Name = this.textBoxName.Text;
                this.MethodAttribute.DataType = this.textBoxDataType.Text;
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void textBox_Validated(object sender, EventArgs e)
        {
            this.errorProvider1.SetError(sender as System.Windows.Forms.Control, null);
        }

        private void textBoxDataType_Validating(object sender, CancelEventArgs e)
        {           
            if (string.IsNullOrEmpty(textBoxDataType.Text))
            {
                e.Cancel = true;
                this.errorProvider1.SetError(sender as System.Windows.Forms.Control, "Pole je poviné");
            }
            else if (Regex.IsMatch(this.textBoxDataType.Text, " *[\\~#%&*{}/:?|\"-]+ *"))
            {
                e.Cancel = true;
                this.errorProvider1.SetError(sender as System.Windows.Forms.Control, "Symbols in text");
            }
        }

        private void textBoxName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxName.Text))
            {
                e.Cancel = true;
                this.errorProvider1.SetError(sender as System.Windows.Forms.Control, "Pole je poviné");
            }
            else if (Regex.IsMatch(this.textBoxName.Text, " *[\\~#%&*{}/:<>?|\"-]+ *"))
            {
                e.Cancel = true;
                this.errorProvider1.SetError(sender as System.Windows.Forms.Control, "Symbols in text");
            }
        }       
    }
}
