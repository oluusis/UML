﻿namespace Projekt3___Paradigm
{
    partial class EditClass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBox1 = new TextBox();
            dataGridViewMethods = new DataGridView();
            dataGridViewProperties = new DataGridView();
            buttonOk = new Button();
            buttonCancel = new Button();
            buttonEdit1 = new Button();
            buttonDelete1 = new Button();
            buttonAdd1 = new Button();
            buttonEdit2 = new Button();
            buttonDelete2 = new Button();
            buttonAdd2 = new Button();
            buttonDelete = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewMethods).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewProperties).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(45, 15);
            label1.Name = "label1";
            label1.Size = new Size(68, 28);
            label1.TabIndex = 0;
            label1.Text = "Name:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(3, 66);
            label2.Name = "label2";
            label2.Size = new Size(110, 28);
            label2.TabIndex = 0;
            label2.Text = "Properties: ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(19, 332);
            label3.Name = "label3";
            label3.Size = new Size(94, 28);
            label3.TabIndex = 0;
            label3.Text = "Methods:";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(119, 15);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(346, 34);
            textBox1.TabIndex = 1;
            // 
            // dataGridViewMethods
            // 
            dataGridViewMethods.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewMethods.Location = new Point(119, 332);
            dataGridViewMethods.Name = "dataGridViewMethods";
            dataGridViewMethods.RowTemplate.Height = 25;
            dataGridViewMethods.Size = new Size(354, 243);
            dataGridViewMethods.TabIndex = 2;
            // 
            // dataGridViewProperties
            // 
            dataGridViewProperties.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewProperties.Location = new Point(119, 66);
            dataGridViewProperties.Name = "dataGridViewProperties";
            dataGridViewProperties.RowTemplate.Height = 25;
            dataGridViewProperties.Size = new Size(354, 243);
            dataGridViewProperties.TabIndex = 2;
            // 
            // buttonOk
            // 
            buttonOk.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonOk.Location = new Point(355, 597);
            buttonOk.Name = "buttonOk";
            buttonOk.Size = new Size(110, 43);
            buttonOk.TabIndex = 3;
            buttonOk.Text = "OK";
            buttonOk.UseVisualStyleBackColor = true;
            buttonOk.Click += buttonOk_Click;
            // 
            // buttonCancel
            // 
            buttonCancel.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonCancel.Location = new Point(239, 597);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(110, 43);
            buttonCancel.TabIndex = 3;
            buttonCancel.Text = "Cancel";
            buttonCancel.UseVisualStyleBackColor = true;
            buttonCancel.Click += buttonCancel_Click;
            // 
            // buttonEdit1
            // 
            buttonEdit1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonEdit1.Location = new Point(36, 208);
            buttonEdit1.Name = "buttonEdit1";
            buttonEdit1.Size = new Size(77, 43);
            buttonEdit1.TabIndex = 3;
            buttonEdit1.Text = "Edit";
            buttonEdit1.UseVisualStyleBackColor = true;
            buttonEdit1.Click += buttonEdit1_Click;
            // 
            // buttonDelete1
            // 
            buttonDelete1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonDelete1.Location = new Point(36, 159);
            buttonDelete1.Name = "buttonDelete1";
            buttonDelete1.Size = new Size(77, 43);
            buttonDelete1.TabIndex = 3;
            buttonDelete1.Text = "Delete";
            buttonDelete1.UseVisualStyleBackColor = true;
            buttonDelete1.Click += buttonDelete1_Click;
            // 
            // buttonAdd1
            // 
            buttonAdd1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonAdd1.Location = new Point(36, 110);
            buttonAdd1.Name = "buttonAdd1";
            buttonAdd1.Size = new Size(77, 43);
            buttonAdd1.TabIndex = 3;
            buttonAdd1.Text = "Add";
            buttonAdd1.UseVisualStyleBackColor = true;
            buttonAdd1.Click += buttonAdd1_Click;
            // 
            // buttonEdit2
            // 
            buttonEdit2.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonEdit2.Location = new Point(36, 474);
            buttonEdit2.Name = "buttonEdit2";
            buttonEdit2.Size = new Size(77, 43);
            buttonEdit2.TabIndex = 3;
            buttonEdit2.Text = "Edit";
            buttonEdit2.UseVisualStyleBackColor = true;
            buttonEdit2.Click += buttonEdit2_Click;
            // 
            // buttonDelete2
            // 
            buttonDelete2.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonDelete2.Location = new Point(36, 425);
            buttonDelete2.Name = "buttonDelete2";
            buttonDelete2.Size = new Size(77, 43);
            buttonDelete2.TabIndex = 3;
            buttonDelete2.Text = "Delete";
            buttonDelete2.UseVisualStyleBackColor = true;
            buttonDelete2.Click += buttonDelete2_Click;
            // 
            // buttonAdd2
            // 
            buttonAdd2.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonAdd2.Location = new Point(36, 376);
            buttonAdd2.Name = "buttonAdd2";
            buttonAdd2.Size = new Size(77, 43);
            buttonAdd2.TabIndex = 3;
            buttonAdd2.Text = "Add";
            buttonAdd2.UseVisualStyleBackColor = true;
            buttonAdd2.Click += buttonAdd2_Click;
            // 
            // buttonDelete
            // 
            buttonDelete.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonDelete.Location = new Point(123, 597);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(110, 43);
            buttonDelete.TabIndex = 3;
            buttonDelete.Text = "Delete";
            buttonDelete.UseVisualStyleBackColor = true;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // EditClass
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(497, 652);
            Controls.Add(buttonDelete);
            Controls.Add(buttonCancel);
            Controls.Add(buttonAdd2);
            Controls.Add(buttonAdd1);
            Controls.Add(buttonDelete2);
            Controls.Add(buttonDelete1);
            Controls.Add(buttonEdit2);
            Controls.Add(buttonEdit1);
            Controls.Add(buttonOk);
            Controls.Add(dataGridViewProperties);
            Controls.Add(dataGridViewMethods);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "EditClass";
            Text = "EditClass";
            ((System.ComponentModel.ISupportInitialize)dataGridViewMethods).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewProperties).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textBox1;
        private DataGridView dataGridViewMethods;
        private DataGridView dataGridViewProperties;
        private Button buttonOk;
        private Button buttonCancel;
        private Button buttonEdit1;
        private Button buttonDelete1;
        private Button buttonAdd1;
        private Button buttonEdit2;
        private Button buttonDelete2;
        private Button buttonAdd2;
        private Button buttonDelete;
    }
}