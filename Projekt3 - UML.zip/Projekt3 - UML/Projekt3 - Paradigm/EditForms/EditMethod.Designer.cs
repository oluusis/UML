﻿namespace Projekt3___Paradigm
{
    partial class EditMethod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            buttonOk = new Button();
            buttonCancel = new Button();
            textBoxName = new TextBox();
            textBoxReturnType = new TextBox();
            errorProvider1 = new ErrorProvider(components);
            comboBox1 = new ComboBox();
            label4 = new Label();
            dataGridViewAttributes = new DataGridView();
            buttonAdd1 = new Button();
            buttonDelete1 = new Button();
            buttonEdit1 = new Button();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewAttributes).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(36, 26);
            label1.Name = "label1";
            label1.Size = new Size(90, 28);
            label1.TabIndex = 0;
            label1.Text = "Visibility:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(46, 86);
            label2.Name = "label2";
            label2.Size = new Size(68, 28);
            label2.TabIndex = 0;
            label2.Text = "Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(7, 387);
            label3.Name = "label3";
            label3.Size = new Size(119, 28);
            label3.TabIndex = 0;
            label3.Text = "Return Type:";
            // 
            // buttonOk
            // 
            buttonOk.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonOk.Location = new Point(259, 443);
            buttonOk.Name = "buttonOk";
            buttonOk.Size = new Size(91, 41);
            buttonOk.TabIndex = 2;
            buttonOk.Text = "Ok";
            buttonOk.UseVisualStyleBackColor = true;
            buttonOk.Click += buttonOk_Click;
            // 
            // buttonCancel
            // 
            buttonCancel.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonCancel.Location = new Point(162, 443);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(91, 41);
            buttonCancel.TabIndex = 3;
            buttonCancel.Text = "Cancel";
            buttonCancel.UseVisualStyleBackColor = true;
            buttonCancel.Click += buttonCancel_Click;
            // 
            // textBoxName
            // 
            textBoxName.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxName.Location = new Point(126, 83);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(243, 34);
            textBoxName.TabIndex = 1;
            textBoxName.Validating += textBoxName_Validating;
            textBoxName.Validated += textBox_Validated;
            // 
            // textBoxReturnType
            // 
            textBoxReturnType.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxReturnType.Location = new Point(126, 387);
            textBoxReturnType.Name = "textBoxReturnType";
            textBoxReturnType.Size = new Size(243, 34);
            textBoxReturnType.TabIndex = 1;
            textBoxReturnType.Validating += textBoxReturnType_Validating;
            textBoxReturnType.Validated += textBox_Validated;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(126, 26);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(243, 36);
            comboBox1.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(12, 135);
            label4.Name = "label4";
            label4.Size = new Size(103, 28);
            label4.TabIndex = 0;
            label4.Text = "Attributes:";
            // 
            // dataGridViewAttributes
            // 
            dataGridViewAttributes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewAttributes.Location = new Point(126, 135);
            dataGridViewAttributes.Name = "dataGridViewAttributes";
            dataGridViewAttributes.RowTemplate.Height = 25;
            dataGridViewAttributes.Size = new Size(243, 231);
            dataGridViewAttributes.TabIndex = 5;
            // 
            // buttonAdd1
            // 
            buttonAdd1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonAdd1.Location = new Point(43, 174);
            buttonAdd1.Name = "buttonAdd1";
            buttonAdd1.Size = new Size(77, 43);
            buttonAdd1.TabIndex = 6;
            buttonAdd1.Text = "Add";
            buttonAdd1.UseVisualStyleBackColor = true;
            buttonAdd1.Click += buttonAdd1_Click;
            // 
            // buttonDelete1
            // 
            buttonDelete1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonDelete1.Location = new Point(43, 223);
            buttonDelete1.Name = "buttonDelete1";
            buttonDelete1.Size = new Size(77, 43);
            buttonDelete1.TabIndex = 7;
            buttonDelete1.Text = "Delete";
            buttonDelete1.UseVisualStyleBackColor = true;
            buttonDelete1.Click += buttonDelete1_Click;
            // 
            // buttonEdit1
            // 
            buttonEdit1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonEdit1.Location = new Point(43, 272);
            buttonEdit1.Name = "buttonEdit1";
            buttonEdit1.Size = new Size(77, 43);
            buttonEdit1.TabIndex = 8;
            buttonEdit1.Text = "Edit";
            buttonEdit1.UseVisualStyleBackColor = true;
            buttonEdit1.Click += buttonEdit1_Click;
            // 
            // EditMethod
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoValidate = AutoValidate.EnableAllowFocusChange;
            ClientSize = new Size(391, 496);
            Controls.Add(buttonAdd1);
            Controls.Add(buttonDelete1);
            Controls.Add(buttonEdit1);
            Controls.Add(dataGridViewAttributes);
            Controls.Add(comboBox1);
            Controls.Add(buttonCancel);
            Controls.Add(buttonOk);
            Controls.Add(textBoxReturnType);
            Controls.Add(textBoxName);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "EditMethod";
            Text = "EditMethod";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewAttributes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Button buttonOk;
        private Button buttonCancel;
        private TextBox textBoxName;
        private TextBox textBoxReturnType;
        private ErrorProvider errorProvider1;
        private ComboBox comboBox1;
        private DataGridView dataGridViewAttributes;
        private Label label4;
        private Button buttonAdd1;
        private Button buttonDelete1;
        private Button buttonEdit1;
    }
}