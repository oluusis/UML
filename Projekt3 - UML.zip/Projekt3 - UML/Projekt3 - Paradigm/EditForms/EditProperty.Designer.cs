﻿namespace Projekt3___Paradigm
{
    partial class EditProperty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            buttonCancel = new Button();
            buttonOk = new Button();
            textBoxDataType = new TextBox();
            textBoxName = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            errorProvider1 = new ErrorProvider(components);
            comboBox1 = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // buttonCancel
            // 
            buttonCancel.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonCancel.Location = new Point(158, 198);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(91, 41);
            buttonCancel.TabIndex = 11;
            buttonCancel.Text = "Cancel";
            buttonCancel.UseVisualStyleBackColor = true;
            buttonCancel.Click += buttonCancel_Click;
            // 
            // buttonOk
            // 
            buttonOk.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonOk.Location = new Point(255, 198);
            buttonOk.Name = "buttonOk";
            buttonOk.Size = new Size(91, 41);
            buttonOk.TabIndex = 10;
            buttonOk.Text = "Ok";
            buttonOk.UseVisualStyleBackColor = true;
            buttonOk.Click += buttonOk_Click;
            // 
            // textBoxDataType
            // 
            textBoxDataType.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxDataType.Location = new Point(127, 81);
            textBoxDataType.Name = "textBoxDataType";
            textBoxDataType.Size = new Size(219, 34);
            textBoxDataType.TabIndex = 7;
            textBoxDataType.Validating += textBoxDateType_Validating;
            textBoxDataType.Validated += control_Validated;
            // 
            // textBoxName
            // 
            textBoxName.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxName.Location = new Point(127, 134);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(219, 34);
            textBoxName.TabIndex = 8;
            textBoxName.Validating += textBoxName_Validating;
            textBoxName.Validated += control_Validated;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(8, 81);
            label3.Name = "label3";
            label3.Size = new Size(103, 28);
            label3.TabIndex = 4;
            label3.Text = "Data Type:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(47, 137);
            label2.Name = "label2";
            label2.Size = new Size(68, 28);
            label2.TabIndex = 5;
            label2.Text = "Name:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(37, 30);
            label1.Name = "label1";
            label1.Size = new Size(90, 28);
            label1.TabIndex = 6;
            label1.Text = "Visibility:";
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(127, 35);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(219, 36);
            comboBox1.TabIndex = 12;
            // 
            // EditProperty
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoValidate = AutoValidate.EnableAllowFocusChange;
            ClientSize = new Size(372, 260);
            Controls.Add(comboBox1);
            Controls.Add(buttonCancel);
            Controls.Add(buttonOk);
            Controls.Add(textBoxDataType);
            Controls.Add(textBoxName);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "EditProperty";
            Text = "EditProperty";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonCancel;
        private Button buttonOk;
        private TextBox textBoxDataType;
        private TextBox textBoxName;
        private Label label3;
        private Label label2;
        private Label label1;
        private ErrorProvider errorProvider1;
        private ComboBox comboBox1;
    }
}