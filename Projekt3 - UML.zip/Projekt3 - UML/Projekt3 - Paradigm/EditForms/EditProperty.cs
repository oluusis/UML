﻿using Projekt3___Paradigm.BO;
using Projekt3___Paradigm.EditForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms;

namespace Projekt3___Paradigm
{
    public partial class EditProperty : Form
    {
        public Property Property { get; set; }

        public EditProperty(Property property)
        {
            this.Property = property;
            InitializeComponent();

            this.comboBox1.DisplayMember = "Text";
            this.comboBox1.ValueMember = "Value";

            this.comboBox1.Items.Add(new { Text = "public", Value = "+" });
            this.comboBox1.Items.Add(new { Text = "protected", Value = "#" });
            this.comboBox1.Items.Add(new { Text = "private", Value = "-" });

            if ("#" == property.Visibility)
            {
                this.comboBox1.SelectedIndex = 1;
            }
            else if ("-" == property.Visibility)
            {
                this.comboBox1.SelectedIndex = 2;
            }
            else
            {
                this.comboBox1.SelectedIndex = 0;
            }

            this.textBoxDataType.Text = property.DataType;
            this.textBoxName.Text = property.Name;
        }


        private void buttonOk_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
            {
                var selectedItem = (comboBox1.SelectedItem as dynamic);

                this.Property.Visibility = selectedItem.Value;
                this.Property.DataType = this.textBoxDataType.Text;
                this.Property.Name = this.textBoxName.Text;
                DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }


        private void control_Validated(object sender, EventArgs e)
        {
            //(Control) sender, null
            this.errorProvider1.SetError(sender as System.Windows.Forms.Control, null);
        }

        private void textBoxName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxName.Text))
            {
                e.Cancel = true;
                this.errorProvider1.SetError(sender as System.Windows.Forms.Control, "Pole je poviné");
            }
            else if (Regex.IsMatch(this.textBoxName.Text, " *[\\~#%&*{}/:<>?|\"-]+ *"))
            {
                e.Cancel = true;
                this.errorProvider1.SetError(sender as System.Windows.Forms.Control, "Symbols in text");
            }

        }

        private void textBoxDateType_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxDataType.Text))
            {
                e.Cancel = true;
                this.errorProvider1.SetError(sender as System.Windows.Forms.Control, "Pole je poviné");
            }
            else if (Regex.IsMatch(this.textBoxDataType.Text, " *[\\~#%&*{}/:?|\"-]+ *"))
            {
                e.Cancel = true;
                this.errorProvider1.SetError(sender as System.Windows.Forms.Control, "Symbols in text");
            }
        }
    }

}
