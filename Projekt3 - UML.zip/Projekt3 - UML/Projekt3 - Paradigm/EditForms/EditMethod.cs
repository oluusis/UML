﻿using Projekt3___Paradigm.BO;
using Projekt3___Paradigm.EditForms;
using Projekt3___Paradigm.Service_classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt3___Paradigm
{
    public partial class EditMethod : Form
    {
        public Method Method { get; set; }
        private Service service { get; set; }

        public EditMethod(Method method)
        {
            this.service = Service.Instance;
            this.Method = method;
            InitializeComponent();

            this.comboBox1.DisplayMember = "Text";
            this.comboBox1.ValueMember = "Value";

            this.comboBox1.Items.Add(new { Text = "public", Value = "+" });
            this.comboBox1.Items.Add(new { Text = "protected", Value = "#" });
            this.comboBox1.Items.Add(new { Text = "private", Value = "-" });

            if ("#" == method.Visibility)
            {
                this.comboBox1.SelectedIndex = 1;
            }
            else if ("-" == method.Visibility)
            {
                this.comboBox1.SelectedIndex = 2;
            }
            else
            {
                this.comboBox1.SelectedIndex = 0;
            }

            this.textBoxName.Text = Method.Name;
            this.textBoxReturnType.Text = Method.ReturnType;

            ResetDataGrid();
        }

        private void ResetDataGrid()
        {
            this.dataGridViewAttributes.DataSource = null;
            this.dataGridViewAttributes.DataSource = Method.Attributes;

            this.dataGridViewAttributes.Columns["ID"].Visible = false;
            this.dataGridViewAttributes.Columns["MethodID"].Visible = false;
            this.dataGridViewAttributes.Columns["GetAttribute"].Visible = false;

            this.dataGridViewAttributes.Refresh();
        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
            {
                var selectedItem = (comboBox1.SelectedItem as dynamic);

                this.Method.Visibility = selectedItem.Value;
                this.Method.Name = this.textBoxName.Text;
                this.Method.ReturnType = this.textBoxReturnType.Text;
                DialogResult = DialogResult.OK;
                this.Close();
            }

        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void textBox_Validated(object sender, EventArgs e)
        {
            this.errorProvider1.SetError(sender as System.Windows.Forms.Control, null);
        }

        private void textBoxName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxName.Text))
            {
                e.Cancel = true;
                this.errorProvider1.SetError(sender as System.Windows.Forms.Control, "Pole je poviné");
            }
            else if (Regex.IsMatch(this.textBoxName.Text, " *[\\~#%&*{}/:<>?|\"-]+ *"))
            {
                e.Cancel = true;
                this.errorProvider1.SetError(sender as System.Windows.Forms.Control, "Symbols in text");
            }
            //else if (!Regex.IsMatch(this.textBoxName.Text, @"^[^\d]+\(.*\)$"))
            //{
            //    e.Cancel = true;
            //    this.errorProvider1.SetError(sender as System.Windows.Forms.Control, "Method(some N atributs)");
            //}
        }

        private void textBoxReturnType_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxReturnType.Text))
            {
                e.Cancel = true;
                this.errorProvider1.SetError(sender as System.Windows.Forms.Control, "Pole je poviné");
            }
            else if (Regex.IsMatch(this.textBoxReturnType.Text, " *[\\~#%&*{}/:?|\"-]+ *"))
            {
                e.Cancel = true;
                this.errorProvider1.SetError(sender as System.Windows.Forms.Control, "Symbols in text");
            }
        }

        private void buttonAdd1_Click(object sender, EventArgs e)
        {
            MethodAttributeEdit form = new MethodAttributeEdit(new MethodAttribute());

            if(form.ShowDialog() == DialogResult.OK)
            {
                this.service.Attributes.Add(form.MethodAttribute);
                this.service.Context.Add(form.MethodAttribute);

                this.service.Context.SaveChanges();
                this.Method.Attributes.Add(this.service.Attributes.Last());

                ResetDataGrid();
            }
        }

        private void buttonDelete1_Click(object sender, EventArgs e)
        {
            int index = this.dataGridViewAttributes.CurrentRow.Index;

            this.service.Context.Remove(Method.Attributes[index]);
            Method.Attributes.RemoveAt(index);

            this.service.Context.SaveChanges();
            ResetDataGrid();
        }

        private void buttonEdit1_Click(object sender, EventArgs e)
        {
            try
            {
                int index = this.dataGridViewAttributes.CurrentRow.Index;

                MethodAttributeEdit form = new MethodAttributeEdit(Method.Attributes[index]);

                if (form.ShowDialog() == DialogResult.OK)
                {
                    MethodAttribute methodAttribute = this.service.Attributes.First(x => x.ID == form.MethodAttribute.ID);
                    methodAttribute = form.MethodAttribute;

                    this.service.Context.SaveChanges();
                    ResetDataGrid();
                }
            }
            catch{ } 
           
        }
    }
}
