﻿namespace Projekt3___Paradigm.EditForms
{
    partial class MethodAttributeEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            buttonCancel = new Button();
            buttonOk = new Button();
            textBoxDataType = new TextBox();
            textBoxName = new TextBox();
            label3 = new Label();
            label2 = new Label();
            errorProvider1 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // buttonCancel
            // 
            buttonCancel.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonCancel.Location = new Point(159, 129);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(91, 41);
            buttonCancel.TabIndex = 17;
            buttonCancel.Text = "Cancel";
            buttonCancel.UseVisualStyleBackColor = true;
            buttonCancel.Click += buttonCancel_Click;
            // 
            // buttonOk
            // 
            buttonOk.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            buttonOk.Location = new Point(256, 129);
            buttonOk.Name = "buttonOk";
            buttonOk.Size = new Size(91, 41);
            buttonOk.TabIndex = 16;
            buttonOk.Text = "Ok";
            buttonOk.UseVisualStyleBackColor = true;
            buttonOk.Click += buttonOk_Click;
            // 
            // textBoxDataType
            // 
            textBoxDataType.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxDataType.Location = new Point(128, 12);
            textBoxDataType.Name = "textBoxDataType";
            textBoxDataType.Size = new Size(219, 34);
            textBoxDataType.TabIndex = 14;
            textBoxDataType.Validating += textBoxDataType_Validating;
            textBoxDataType.Validated += textBox_Validated;
            // 
            // textBoxName
            // 
            textBoxName.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxName.Location = new Point(128, 65);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(219, 34);
            textBoxName.TabIndex = 15;
            textBoxName.Validating += textBoxName_Validating;
            textBoxName.Validated += textBox_Validated;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(9, 12);
            label3.Name = "label3";
            label3.Size = new Size(103, 28);
            label3.TabIndex = 12;
            label3.Text = "Data Type:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(48, 68);
            label2.Name = "label2";
            label2.Size = new Size(68, 28);
            label2.TabIndex = 13;
            label2.Text = "Name:";
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // MethodAttributeEdit
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(362, 181);
            Controls.Add(buttonCancel);
            Controls.Add(buttonOk);
            Controls.Add(textBoxDataType);
            Controls.Add(textBoxName);
            Controls.Add(label3);
            Controls.Add(label2);
            Name = "MethodAttributeEdit";
            Text = "MethodAttributeEdit";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonCancel;
        private Button buttonOk;
        private TextBox textBoxDataType;
        private TextBox textBoxName;
        private Label label3;
        private Label label2;
        private ErrorProvider errorProvider1;
    }
}