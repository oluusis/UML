﻿using Projekt3___Paradigm.BO;
using Projekt3___Paradigm.Service_classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt3___Paradigm
{
    public partial class EditClass : Form
    {
        private Service service { get; set; }

        public Class Class { get; set; }

        public EditClass(Class c)
        {
            this.service = Service.Instance;
            this.Class = c;

            InitializeComponent();

            ResetDataGrid();
            this.textBox1.Text = c.Name;
        }

        private void ResetDataGrid()
        {
            this.dataGridViewMethods.DataSource = null;
            this.dataGridViewProperties.DataSource = null;
            this.dataGridViewMethods.DataSource = Class.Methods;
            this.dataGridViewProperties.DataSource = Class.Properties;

            dataGridViewMethods.AutoGenerateColumns = true;
            dataGridViewProperties.AutoGenerateColumns = true;

            this.dataGridViewMethods.Columns["ID"].Visible = false;
            this.dataGridViewMethods.Columns["ClassID"].Visible = false;
            this.dataGridViewMethods.Columns["GetValues"].Visible = false;

            this.dataGridViewProperties.Columns["ID"].Visible = false;
            this.dataGridViewProperties.Columns["ClassID"].Visible = false;
            this.dataGridViewProperties.Columns["GetValues"].Visible = false;

            this.dataGridViewMethods.Refresh();
            this.dataGridViewProperties.Refresh();
        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            this.Class.Name = this.textBox1.Text;
            this.DialogResult = DialogResult.OK;

        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void buttonAdd1_Click(object sender, EventArgs e)
        {
            EditProperty form = new EditProperty(new Property() { ClassID = Class.ID });

            if (form.ShowDialog() == DialogResult.OK)
            {
                this.service.Properties.Add(form.Property);
                this.service.Context.Add(form.Property);

                this.service.Context.SaveChanges();
                this.Class.Properties.Add(form.Property);
                ResetDataGrid();
            }
        }

        private void buttonAdd2_Click(object sender, EventArgs e)
        {
            EditMethod form = new EditMethod(new Method() { ClassID = Class.ID });

            if (form.ShowDialog() == DialogResult.OK)
            {
                this.service.Methods.Add(form.Method);
                this.service.Context.Add(form.Method);

                this.service.Context.SaveChanges();
                this.Class.Methods.Add(form.Method);
                ResetDataGrid();
            }
        }

        private void buttonEdit1_Click(object sender, EventArgs e)
        {
            if (this.dataGridViewProperties.CurrentRow != null)
            {
                int index = this.dataGridViewProperties.CurrentRow.Index;
                EditProperty form = new EditProperty(Class.Properties[index]);

                if (form.ShowDialog() == DialogResult.OK)
                {
                    Property edit = this.service.Properties.First(x => x.ID == form.Property.ID);
                    edit = form.Property;

                    this.service.Context.SaveChanges();
                    ResetDataGrid();
                }
            }
        }

        private void buttonEdit2_Click(object sender, EventArgs e)
        {
            if (this.dataGridViewMethods.CurrentRow != null)
            {
                int index = this.dataGridViewMethods.CurrentRow.Index;
                EditMethod form = new EditMethod(Class.Methods[index]);

                if (form.ShowDialog() == DialogResult.OK)
                {
                    Method edit = this.service.Methods.First(x => x.ID == form.Method.ID);
                    edit = form.Method;

                    this.service.Context.SaveChanges();
                    ResetDataGrid();
                }

            }
        }

        private void buttonDelete1_Click(object sender, EventArgs e)
        {
            if (this.dataGridViewProperties.CurrentRow != null)
            {
                int index = this.dataGridViewProperties.CurrentRow.Index;

                this.service.Context.Remove(Class.Properties[index]);
                Class.Properties.RemoveAt(index);

                this.service.Context.SaveChanges();
                ResetDataGrid();
            }
        }

        private void buttonDelete2_Click(object sender, EventArgs e)
        {
            if (this.dataGridViewMethods.CurrentRow != null)
            {
                int index = this.dataGridViewMethods.CurrentRow.Index;

                this.service.Context.Remove(Class.Methods[index]);
                Class.Methods.RemoveAt(index);

                this.service.Context.SaveChanges();
                ResetDataGrid();
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            foreach (var item in Class.Properties)
            {
                this.service.Properties.Remove(item);
                this.service.Context.Remove(item);
            }

            foreach (var item in Class.Methods)
            {
                this.service.Methods.Remove(item);
                this.service.Context.Remove(item);
            }

            this.service.Classes.Remove(Class);
            this.service.Context.Remove(Class);

            this.service.Context.SaveChanges();
            this.Close();
        }
    }
}
