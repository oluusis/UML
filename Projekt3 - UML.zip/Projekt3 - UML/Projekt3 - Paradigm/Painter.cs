﻿using Projekt3___Paradigm.BO;
using Projekt3___Paradigm.Changers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt3___Paradigm
{
    public class Painter
    {
        public Font Font { get; set; }

        public Pen Color { get; set; }

        public float spaceBetween { get; set; }

        public Painter() 
        {
            this.Font = new Font("Arial", 10);
            this.Color = new Pen(Brushes.Black,1f);
        }   

        public void PaintClass(Class c, Graphics g )
        {
            g.FillRectangle(Brushes.Aqua, c.PositionX, c.PositionY, c.Width, c.Height);
            g.DrawString(c.Name, this.Font, Brushes.Black, (c.Width / 2 + c.PositionX) - (g.MeasureString(c.Name, Font).Width / 2), c.PositionY + 5);
            g.DrawLine(Color, c.PositionX, c.PositionY + 25, c.PositionX + c.Width, c.PositionY + 25);

            float currentRow = c.PositionY + 25;

        
            spaceBetween = (c.Height - 25 - (c.Properties.Count * 15 + c.Methods.Count * 15))/4;

            currentRow += spaceBetween; 

            if(c.Properties != null)
            {
                for (int i = 0; i < c.Properties.Count; i++)
                {
                    g.DrawString(c.Properties[i].GetValues, this.Font, Brushes.Black, c.PositionX + 5, currentRow);
                    currentRow += 15;
                }
            }
            currentRow += spaceBetween;
             g.DrawLine(Color, c.PositionX, currentRow, c.PositionX + c.Width, currentRow);

            currentRow += spaceBetween;
            if (c.Methods != null)
            {
                for (int i = 0; i < c.Methods.Count; i++)
                {
                    
                    g.DrawString(c.Methods[i].GetValues, this.Font, Brushes.Black, c.PositionX + 5, currentRow);
                    currentRow += 15;

                }
            }
        }

        public void PaintArrow(Arrow a, Graphics g)
        {
            g.FillRectangle(Brushes.Black, a.StartX - 5, a.StartY - 5, 10, 10);
            g.DrawLine(Color, a.StartX, a.StartY, a.FirstPointX, (a.StartY + a.EndY) / 2);
            g.DrawLine(Color, a.FirstPointX, (a.StartY + a.EndY) /2, a.SecondPointX, (a.StartY + a.EndY) / 2);
            g.DrawLine(Color, a.SecondPointX, (a.StartY + a.EndY) / 2, a.EndX, a.EndY);
            g.FillEllipse(Brushes.Black, a.EndX-5, a.EndY-5, 10, 10);
        }
    }
}
