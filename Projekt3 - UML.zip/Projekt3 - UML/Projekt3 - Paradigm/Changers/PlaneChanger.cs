﻿using Projekt3___Paradigm.Service_classes;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt3___Paradigm.Changers
{
    public class PlaneChanger
    {
        private Point fromPos { get; set; } = new Point();

        public Point lastPos { get; set; }

        public bool changing { get; set; }

        private static PlaneChanger _instance { get; set; }

        public PlaneChanger(Point fromPos)
        {
            this.fromPos = fromPos;
            changing = true;
        }

        public static PlaneChanger GetInstance(Point fromPos)
        {
            if (_instance == null)
            {
                _instance = new PlaneChanger(fromPos);
            }
            _instance.fromPos = fromPos;
            return _instance;

        }

        public void MovePlane(Graphics g)
        {
            float Vx = lastPos.X - fromPos.X;
            float Vy = lastPos.Y - fromPos.Y;

            g.TranslateTransform( g.Transform.OffsetX + Vx, g.Transform.OffsetY + Vy);
        }
    }
}
