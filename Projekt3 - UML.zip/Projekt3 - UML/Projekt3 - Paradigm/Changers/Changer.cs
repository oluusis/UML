﻿using Projekt3___Paradigm.BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt3___Paradigm.Changers
{
    public class Changer
    {
        public float LengthX { get; set; }
        public float LengthY { get; set; }

        public Class Class { get; set; }

        public float EndX { get; set; }
        public float EndY { get; set; }

        public virtual void Move(Point position)
        {

        }
    }
}
