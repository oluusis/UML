﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt3___Paradigm.Changers
{
    public class ScaleTransform
    {
        public int Delta { get; set; }
        public Point MousePoint { get; set; }   
        public PictureBox CurrentPicBox { get; set; }   

        public ScaleTransform(int delta, Point mousePosition, PictureBox currentPicBox) 
        { 
            this.Delta = delta;
            this.MousePoint = mousePosition;
            this.CurrentPicBox = currentPicBox;
        }

        public Size UpdatePictureBoxZoom(Size currentSize)
        {
            //int Width = CurrentPicBox.Size.Width * Delta/10;
            //int Height = CurrentPicBox.Size.Height * Delta/10;

            //int X = CurrentPicBox.Left - MousePoint.X - CurrentPicBox.Left * (Delta - 1);
            //int Y = CurrentPicBox.Top - MousePoint.Y - CurrentPicBox.Top * (Delta - 1);

            currentSize.Width += Delta / 10;
            currentSize.Height += Delta / 10;

            CurrentPicBox.Scale(currentSize);
            //CurrentPicBox.Location = new Point(X, Y);

            return currentSize;
        }
    }
}
