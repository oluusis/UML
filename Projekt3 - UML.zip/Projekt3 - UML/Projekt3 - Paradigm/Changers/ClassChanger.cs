﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Projekt3___Paradigm.BO;

namespace Projekt3___Paradigm.Changers
{
    public class ClassChanger : Changer
    {
        public Point StartP { get; set; }
        public Point EndP { get; set; }

        public float StartX { get; set; }
        public float StartY { get; set; }

        private Point LongestStringSize { get; set; }


        public ClassChanger(Point startP, Class AttachedClass)
        {
            StartP = startP;
            Class = AttachedClass;


            StartX = AttachedClass.PositionX;
            StartY = AttachedClass.PositionY;

            LengthX = StartP.X - Class.PositionX;
            LengthY = StartP.Y - Class.PositionY;

            EndX = Class.PositionX + AttachedClass.Width;
            EndY = Class.PositionY + AttachedClass.Height;

            string longestString = "New class";
            int countItems = 0;

            foreach (var item in Class.Properties)
            {
                if (item.GetValues.Length > longestString.Length)
                {
                    longestString = item.GetValues;
                }
                countItems++;
            }

            foreach (var item in Class.Methods)
            {
                if (item.GetValues.Length > longestString.Length)
                {
                    longestString = item.GetValues;
                }
                countItems++;
            }

            LongestStringSize = new Point(TextRenderer.MeasureText(longestString, new Font("Arial", 10)).Width,
                                          TextRenderer.MeasureText(longestString, new Font("Arial", 10)).Height * countItems + 25);
        }


        public void UpdateSize()
        {
            Move(new Point(Convert.ToInt32(StartX), Convert.ToInt32(StartY)));
            Move(new Point(Convert.ToInt32(EndX), Convert.ToInt32(EndY)));
        }

        private bool ControlMinSizeLeft(Point mousePosition)
        {

            if (Class.Width > LongestStringSize.X)
            {
                return true;

            }
            else if (EndX - mousePosition.X > LongestStringSize.X)
            {
                return true;
            }

            return false;
        }

        private bool ControlMinSizeUp(Point mousePosition)
        {

            if (Class.Height > LongestStringSize.Y)
            {
                return true;

            }
            else if (EndY - mousePosition.Y > LongestStringSize.Y)
            {
                return true;
            }

            return false;
        }


        private void ChangeSizeLeft(Point mousePosition)
        {
            if (ControlMinSizeLeft(mousePosition))
            {
                Class.PositionX = mousePosition.X - LengthX;
                Class.Width = EndX - Class.PositionX;
            }
            changeSize = true;
        }

        private void ChangeSizeUp(Point mousePosition)
        {
            if (ControlMinSizeUp(mousePosition))
            {
                Class.PositionY = mousePosition.Y - LengthY;
                Class.Height = EndY - Class.PositionY;

            }
            changeSize = true;

        }

        private void ChangeSizeRight(Point mousePosition)
        {
            Class.Width = Math.Max(mousePosition.X - Class.PositionX, LongestStringSize.X);
            EndX = Class.PositionX + Class.Width;
            changeSize = true;
        }

        private void ChangeSizeDown(Point mousePosition)
        {
            Class.Height = Math.Max(mousePosition.Y - Class.PositionY, LongestStringSize.Y);
            EndY = Class.PositionY + Class.Height;
            changeSize = true;

        }


        private bool changeSize = false;
        private bool move = false;

        public override void Move(Point mousePosition)
        {
            if (!move)
            {
                float directionX = Class.PositionX;
                float directionY = Class.PositionY;

                if (mousePosition.Y - Class.PositionY < 10 && mousePosition.Y - Class.PositionY > -10)
                {
                    ChangeSizeUp(mousePosition);
                }

                if (mousePosition.Y - EndY < 10 && mousePosition.Y - EndY > -10)
                {
                    ChangeSizeDown(mousePosition);
                }

                if (mousePosition.X - EndX < 10 && mousePosition.X - EndX > -10)
                {
                    ChangeSizeRight(mousePosition);
                }

                if (mousePosition.X - Class.PositionX < 10 && mousePosition.X - Class.PositionX > -10)
                {
                    ChangeSizeLeft(mousePosition);
                }

                ChangeArrow(directionX, directionY);
            }

            if (!changeSize)
            {
                float directionX = Class.PositionX;
                float directionY = Class.PositionY;

                Class.PositionX = mousePosition.X - LengthX;
                Class.PositionY = mousePosition.Y - LengthY;
                move = true;

               ChangeArrow(directionX, directionY);
            }
        }

        private void ChangeArrow(float directionX, float directionY)
        {
            directionX -= Class.PositionX;
            directionY -= Class.PositionY;

            ArrowChanger arrowChanger = new ArrowChanger(Class);
            arrowChanger.ArrowEditMoveChildren(directionX, directionY);
            arrowChanger.ArrowEditMoveParents(directionX, directionY);

        }
    }
}
