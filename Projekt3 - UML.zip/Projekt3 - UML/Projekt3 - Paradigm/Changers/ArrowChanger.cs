﻿using MySqlX.XDevAPI.Relational;
using Projekt3___Paradigm.BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt3___Paradigm.Changers
{
    public class ArrowChanger : Changer
    {
        public Arrow Arrow { get; set; }

        public ArrowChanger(Arrow arrow, Class attachedClass)
        {
            arrow.EndX = arrow.StartX;
            arrow.EndY = arrow.StartY;
            this.Arrow = arrow;
            base.Class = attachedClass;

            PickNearestWall(this.Arrow,true);
        }

        public ArrowChanger(Class attachedClass)
        {
            base.Class = attachedClass;
        }


        public override void Move(Point position)
        {
            Arrow.EndX = position.X;
            Arrow.EndY = position.Y;

            float middle = (Arrow.StartY + Arrow.EndY) / 2;

            Arrow.FirstPointX = Arrow.StartX;
            Arrow.FirstPointY = middle;


            Arrow.SecondPointX = Arrow.EndX;
            Arrow.SecondPointY = middle;

        }

        public void PickNearestWall(Arrow arrow, bool clickStart)
        {
            float pX = 0;
            float pY = 0;

            if (clickStart) 
            {
                pX = arrow.StartX;
                pY = arrow.StartY;
            }
            else
            {
                pX = arrow.EndX;
                pY = arrow.EndY;
            }


            float possibleWallY = 0f;
            

            if(Class.PositionY + Class.Height - pY > pY - Class.PositionY )
            {
                possibleWallY = Class.PositionY;
                base.LengthY = pY - Class.PositionY;
            }
            else
            {
                possibleWallY = Class.PositionY + Class.Height;
                base.LengthY = Class.PositionY + Class.Height - pY;
            }

            float possibleWallX = 0f;

            if (Class.PositionX + Class.Width - pX  > pX - Class.PositionX)
            {
                possibleWallX = Class.PositionX;
                base.LengthX = pX - Class.PositionX;

                SetArrowToWall(possibleWallX, possibleWallY, clickStart);
            }
            else
            {
                possibleWallX = Class.PositionX + Class.Width;
                base.LengthX = Class.PositionX + Class.Width - pX;

                SetArrowToWall(possibleWallX, possibleWallY, clickStart);
            }
            base.LengthX = 0f;
            base.LengthY = 0f;
        }


        private void SetArrowToWall(float toWallX, float toWallY, bool clickStart)
        {
            if (base.LengthY > base.LengthX)
            {
                if (clickStart) {
                    this.Arrow.StartX = toWallX;
                    return;
                }
                this.Arrow.EndX = toWallX;

            }
            else
            {
                if (clickStart){
                    this.Arrow.StartY = toWallY;
                    return;
                }
                this.Arrow.EndY = toWallY;
            }
        }


        public void ArrowEditMoveChildren(float directionX, float directionY)
        {
            foreach (var arrow in Class.Children)
            {
                arrow.EndX -= directionX;
                arrow.EndY -= directionY;

                arrow.SecondPointX -= directionX;
                arrow.SecondPointY -= directionY;

                arrow.FirstPointY -= directionY;
            }
        }

        public void ArrowEditMoveParents(float directionX, float directionY)
        {
            foreach (var arrow in Class.Parents)
            {
                arrow.StartX -= directionX;
                arrow.StartY -= directionY;

                arrow.FirstPointX -= directionX;
                arrow.FirstPointY -= directionY;

                arrow.SecondPointY -= directionY;
            }
        }
    }
}
