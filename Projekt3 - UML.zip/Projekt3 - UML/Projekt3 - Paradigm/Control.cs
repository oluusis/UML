﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Projekt3___Paradigm.BO;
using Projekt3___Paradigm.Changers;
using Projekt3___Paradigm.Service_classes;
using ZstdSharp.Unsafe;

namespace Projekt3___Paradigm
{
    public class Control
    {

        public Service ClassService { get; set; }

        public Painter Painter { get; set; }
        public ClassChanger ClassChanger { get; set; }
        public ArrowChanger ArrowChanger { get; set; }
        public PlaneChanger PlaneMover { get; set; }

        public Class AttachedClass { get; set; }
        public Arrow AttachedArrow { get; set; }

        public Control()
        {
            ClassService = Service.Instance;
            Painter = new Painter();

        }

        public bool ClickClass(Point mousePosition)
        {
            foreach (var c in ClassService.Classes)
            {
                if((mousePosition.X >= c.PositionX) && 
                   (mousePosition.X <= c.PositionX + c.Width) &&
                   mousePosition.Y >= c.PositionY &&
                   mousePosition.Y <= c.PositionY + c.Height)
                {
                    this.AttachedClass = c;
                    return true;

                }
            }
            return false;
        }



        public void UpdateSize(Point mousePosition)
        {
            ClassChanger changer = new ClassChanger(mousePosition, AttachedClass);
            changer.UpdateSize();
        }



        public void Draw(Graphics g)
        {
            if(PlaneMover != null)
            {
              PlaneMover.MovePlane(g);
            }

            foreach (var Arrow in ClassService.Arrows)
            {
                Painter.PaintArrow(Arrow, g);
            }

            foreach (var Class in ClassService.Classes)
            {
                Painter.PaintClass(Class, g);
            } 
        }


        public void CreateClass(Point position)
        {
            Class newClass = new Class("New class", position.X, position.Y);
            this.ClassService.Context.Add(newClass);
            this.ClassService.Classes.Add(newClass);
           
            this.ClassService.Context.SaveChanges();
        }


        public event Action<Point> moveEvent;

        private bool stopMoveClass = false;
        public void MouseDown(Point mousePosition)
        {
            if (ClickClass(mousePosition))
            {
                if (stopMoveClass) return;

                ClassChanger = new ClassChanger(mousePosition, AttachedClass);
                this.moveEvent += ClassChanger.Move;
            }
        }

        public void MouseUp(Point mousePosition) 
        {
            if (!ClickClass(mousePosition)) return;

            if (ClassChanger == null) return;



            this.moveEvent -= ClassChanger.Move;

        }

 
        public void MouseMove(Point mousePosition)
        {
            if(ClassChanger != null)
            {
                this.moveEvent?.Invoke(mousePosition);
            }


            if (PlaneMover != null)
            {
                if (this.PlaneMover.changing == true) this.PlaneMover.lastPos = mousePosition;
            }
               
        }

        public void CreateArrow(Point mousePosition)
        {
            if (!ClickClass(mousePosition)) return;

            stopMoveClass = true;
            
            this.AttachedArrow = new Arrow(mousePosition.X,mousePosition.Y,AttachedClass.ID);

            this.ArrowChanger = new ArrowChanger(AttachedArrow, AttachedClass);
           this.moveEvent += this.ArrowChanger.Move;

            this.ClassService.Context.Add(AttachedArrow);
            this.ClassService.Arrows.Add(AttachedArrow);     
        }

        public void EndArrow(Point mousePosition)
        {
            if (!ClickClass(mousePosition)) return;

            if (this.moveEvent == null) return;
            this.moveEvent -= this.ArrowChanger.Move;

            this.ArrowChanger.Class = this.AttachedClass;
            this.ArrowChanger.PickNearestWall(AttachedArrow, false);
            stopMoveClass = false;
            AttachedArrow.IDChild = AttachedClass.ID;

            Arrow arrowUpdate = this.ClassService.Arrows.First(x => x.ID == this.AttachedArrow.ID);
            arrowUpdate = AttachedArrow;

            this.ClassService.Context.Add(AttachedArrow);
            //this.ClassService.Context.SaveChanges();
            this.ClassService.ResetArrows();

            this.AttachedArrow = null;
        }

        public void CancelArrow()
        {
            if (this.AttachedArrow == null) return;

            stopMoveClass = false;
            this.moveEvent -= this.ArrowChanger.Move;
            //this.ClassService.Context.Remove(this.AttachedArrow);
            this.ClassService.Arrows.Remove(this.AttachedArrow);
            //this.ClassService.Context.SaveChanges();
        }


        private Size currentSize = new Size();
        public void Zoom(int delta, Point mousePosition, PictureBox currentPicBox)
        {
            ScaleTransform scaleTransform = new ScaleTransform(delta,mousePosition,currentPicBox);
            this.currentSize = scaleTransform.UpdatePictureBoxZoom(currentSize);
        }
    }
}
