﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt3___Paradigm.BO
{
    public class Method
    {
        public int ID { get; set; }

        public int ClassID { get; set; }

        public string Visibility { get; set; }

        public string Name { get; set; }

        public string ReturnType { get; set; }

        public BindingList<MethodAttribute>? Attributes { get; set; } = new BindingList<MethodAttribute>();

        public  string GetValues
        {
            get
            {
                string attributes = "";
                for (int i = 0; i < Attributes.Count; i++)
                {
                    if(i+1 == Attributes.Count)
                    {
                        attributes += Attributes[i].GetAttribute;
                        break;
                    }
                    attributes += Attributes[i].GetAttribute + ',';
                }

                return $"{Visibility} {Name}({attributes}) {ReturnType}";
            }
        }

        public Method()
        {
        }
             
    }
}
