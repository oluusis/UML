﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt3___Paradigm.BO
{
    public class MethodAttribute
    {
        public int ID {  get; set; }

        public int MethodID { get; set; }

        public string DataType { get; set; }

        public string Name { get; set; }

        public string GetAttribute { get
            {
                return this.DataType + " " + this.Name;
            } 
        }

        public MethodAttribute()
        {

        }

    }
}
