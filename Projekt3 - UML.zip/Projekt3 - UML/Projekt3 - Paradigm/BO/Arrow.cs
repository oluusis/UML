﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt3___Paradigm.BO
{
    public class Arrow
    {
        public int ID { get; set; }

        public int IDParent { get; set; }
        public int IDChild { get; set; }

        public float StartX { get; set; }
        public float StartY { get; set; }

        public float FirstPointX { get; set; } = 0;
        public float FirstPointY { get; set; } = 0;

        public float SecondPointX { get; set; } = 0;
        public float SecondPointY { get; set; } = 0;

        public float EndX { get; set; }
        public float EndY { get; set; } 

        public Arrow()
        {

        }

        public Arrow(float startX, float starY, int parentID)
        {
            this.StartX = startX;
            this.StartY = starY;

            this.EndX = startX;
            this.EndY = starY;

            this.IDParent = parentID;
        }
    }
}
