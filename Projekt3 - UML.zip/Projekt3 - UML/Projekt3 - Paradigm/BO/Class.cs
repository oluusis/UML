﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt3___Paradigm.BO
{
    public class Class
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public List<Property> Properties = new List<Property>();
        public List<Method> Methods = new List<Method>();
        public List<Arrow> Children = new List<Arrow>();
        public List<Arrow> Parents = new List<Arrow>();

        public float PositionX { get; set; }
        public float PositionY { get; set; }

        public float Height { get; set; }
        public float Width { get; set; }     


        public Class(string name, float positionX, float positionY)
        {
            Height = Width = 100f;

            Name = name;
            PositionX = positionX - Width/2;
            PositionY = positionY;
            
        }

        public Class() { }


    }

}
