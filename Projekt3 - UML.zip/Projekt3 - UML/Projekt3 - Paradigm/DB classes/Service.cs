﻿using Projekt3___Paradigm.BO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt3___Paradigm.Service_classes
{
    public class Service
    {
        public MyContext Context = new MyContext();

        public BindingList<Class> Classes { get; set; }
        public BindingList<Property> Properties { get; set; }
        public BindingList<Method> Methods { get; set; }
        public BindingList<Arrow> Arrows { get; set; }
        public BindingList<MethodAttribute> Attributes { get; set; }

        private static Service _instance {  get; set; }    

        public static Service Instance { 
            get
            {
                if( _instance == null)
                {
                    _instance = new Service();
                }
                return _instance;
            } 
        }
      
        public Service() 
        {
            this.Classes = new BindingList<Class>(Context.Classes.ToList());
            this.Properties = new BindingList<Property>(Context.Properties.ToList());
            this.Methods = new BindingList<Method>(Context.Methods.ToList());
            this.Arrows = new BindingList<Arrow>(Context.Arrows.ToList());
            this.Attributes = new BindingList<MethodAttribute>(Context.MethodAttributes.ToList());

            foreach (var prop in this.Properties)
            {
                Classes.ToList().Find(x => x.ID == prop.ClassID).Properties.Add(prop);
            }

            foreach (var method in this.Methods)
            {
                Classes.ToList().Find(x => x.ID == method.ClassID).Methods.Add(method);
            }

            foreach (var attribute in this.Attributes)
            {
                //Methods.ToList().Find(x => x.ID == attribute.MethodID).Attributes.Add(attribute);
            }

            ResetArrows();
        }

        public void ResetArrows()
        {
            foreach (var c in this.Classes)
            {
                c.Children = this.Arrows.Where(x => c.ID == x.IDChild).ToList();
                c.Parents = this.Arrows.Where(x => c.ID == x.IDParent).ToList();
            }
        }

    }
}
