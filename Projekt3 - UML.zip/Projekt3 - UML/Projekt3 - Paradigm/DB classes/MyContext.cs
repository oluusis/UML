﻿using Microsoft.EntityFrameworkCore;
using Projekt3___Paradigm.BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt3___Paradigm
{
    public class MyContext : DbContext
    {
        public DbSet<Class> Classes { get; set; }

        public DbSet<Method> Methods { get; set; }

        public DbSet<Property> Properties { get; set; }

        public DbSet<Arrow> Arrows { get; set; }

        public DbSet<MethodAttribute> MethodAttributes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySQL("server=mysqlstudenti.litv.sssvt.cz;database=4a2_hrubanoliver_db1;user=hrubanoliver;password=123456;SslMode=none");
        }
    }
}

